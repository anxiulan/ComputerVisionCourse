#include <map/observation.h>

namespace map {
constexpr int Observation::NO_SEMANTIC_VALUE;
}
