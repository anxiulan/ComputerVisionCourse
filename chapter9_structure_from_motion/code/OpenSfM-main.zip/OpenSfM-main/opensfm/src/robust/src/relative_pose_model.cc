#include "robust/relative_pose_model.h"

const int RelativePose::MINIMAL_SAMPLES;
