#include "robust/line_model.h"

const int Line::MINIMAL_SAMPLES;
