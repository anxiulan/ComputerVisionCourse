.. OpenSfM documentation primary file

OpenSfM
=======

.. toctree::
   :maxdepth: 1

   building
   using
   dataset
   geometry
   cam_coord_system
   reconstruction_module
   large
   reporting
   quality_report
   rig
   annotation_tool
   api

Indices and tables
==================

* :ref:`genindex`
