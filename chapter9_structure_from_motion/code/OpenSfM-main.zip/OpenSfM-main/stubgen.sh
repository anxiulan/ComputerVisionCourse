#!/bin/bash

stubgen -o . -m opensfm.pybundle
stubgen -o . -m opensfm.pyfeatures
stubgen -o . -m opensfm.pymap
stubgen -o . -m opensfm.pysfm
stubgen -o . -m opensfm.pydense
stubgen -o . -m opensfm.pygeometry
stubgen -o . -m opensfm.pyrobust
